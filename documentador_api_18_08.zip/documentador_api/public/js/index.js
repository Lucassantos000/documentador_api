
function toggleRespsota(elemento, indice){
    // console.log(elemento.parentNode.parentNode.parentNode.querySelectorAll(".content_dados_enviados")[indice])
    elemento.parentNode.parentNode.parentNode.querySelectorAll(".content_dados_enviados")[indice].classList.toggle("ativo")
}


document.querySelectorAll(".title_rota").forEach((elemento)=>{
    console.log(elemento)
    elemento.addEventListener("click", (e)=>{
        elemento.parentNode.parentNode.classList.toggle("active");
    })
})