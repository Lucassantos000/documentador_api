const mysql = require('mysql2');

// Create the connection pool. The pool-specific settings are the defaults
const credentials = {
  host: 'localhost',
  user: 'root',
  database: 'controle_compra_api_mercado_pago',
  password: "admin",
  waitForConnections: true,
  connectionLimit: 10,
  maxIdle: 10, // max idle connections, the default value is the same as `connectionLimit`
  idleTimeout: 60000, // idle connections timeout, in milliseconds, the default value 60000
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0
}

const pool = mysql.createPool(credentials);
const promisePool = pool.promise();

  // query database using promises
  // const [rows,fields] = await promisePool.query("SHOW TABLES;");
  // console.log(rows)

module.exports ={
  promisePool
}

