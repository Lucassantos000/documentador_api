const poll = require("../db/db").promisePool


const busca_compras_aluno = async ()=>{
    const [rows,fields] = await poll.query("SELECT * FROM `compras` WHERE computada = 0 ORDER BY data_solicitacao DESC;");
    return rows
}


module.exports ={
    busca_compras_aluno
}