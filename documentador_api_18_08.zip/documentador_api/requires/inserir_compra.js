const poll = require("../db/db").promisePool


const inserir_compra = async (valor, cafe, almoco, lanche, jantar,id_transacao_mp, link_pagamento, data_solicitacao, data_expiracao, forma_pagamento)=>{
    const [rows,fields] = await poll.query(`
    INSERT INTO compras (id_aluno, valor, cafe, almoco, 
        lanche, jantar, id_transacao_mp, link_pagamento,
        data_solicitacao, data_expiracao,
        forma_pagamento) VALUES (1, ${valor} , ${cafe}, ${almoco}, ${lanche}, ${jantar}, "${id_transacao_mp}", "${link_pagamento}", "${data_solicitacao}", "${data_expiracao}", "${forma_pagamento}");
    `);
    console.log(fields)
    console.log(rows)
    return rows
}


module.exports ={
    inserir_compra
}