require('dotenv').config()
console.log(process.env)
const express = require("express");
const app = express();

app.use(express.static("public"));

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())


app.set('view engine', 'ejs');
app.set('views', './views');

const cors = require("cors");
app.use(cors())

const fetch = require("node-fetch");


/*app.use((req, res, next) => {
	//Qual site tem permissão de realizar a conexão, no exemplo abaixo está o "*" indicando que qualquer site pode fazer a conexão
    res.header("Access-Control-Allow-Origin", "*");
	//Quais são os métodos que a conexão pode realizar na API
    res.header("Access-Control-Allow-Methods", 'GET,PUT,POST,DELETE');
    app.use(cors());
    next();
});*/

app.get("/", (req,res)=>{
    res.render("index.ejs")
})




app.listen(process.env.PORTA, ()=>{
    console.log("servidor rodando na porta ", process.env.PORTA)
})
